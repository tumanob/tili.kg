<?php get_header(); ?>
	<div id="wrapper">
			<div class="post">
				<h2>Ошибка 404</h2>
				<p>Страница не найдена. Перейти на <a href="<?php bloginfo('url'); ?>">главную страницу</a>.</p>
				<img src="<?php bloginfo('url'); ?>/wp-content/uploads/2011/12/404.png" />
			</div>
	</div>
<?php get_footer(); ?>