
    <div class="empty"></div>
</div>
<div id="footer">
	<div class="inner row">

                  <div class="copyright  col-xs-4 col-md-2 col-sm-3">
                    <h3>TILI.KG</h3>
                    &copy; Все права защищены. <br/>
                    <div class="sbut">
                        <div class="fb-like" data-href="http://tili.kg/" data-send="false" data-layout="button_count" data-width="170" data-show-faces="false" data-font="verdana"></div>
                    </div>
                    <div class="sbut">
                        <div class="g-plusone" data-size="medium"></div>
                    </div>
                    <div class="sbut">
                        <a href="https://twitter.com/share" class="twitter-share-button" data-lang="ru">Tweet</a>
                        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                    </div>
                  </div>
                  <div class="col-xs-8 col-md-4 col-sm-4">
                      <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="300" height="75"	id="20050.swf" align="middle">
                      <param name="allowScriptAccess" value="sameDomain">
                      <param name="movie"
                      value="http://tili.kg/banners/20050.swf">
                      <param name="quality" value="high">
                      <param name="bgcolor" value="#ffffff">
                      <embed src="http://tili.kg/banners/20050.swf" quality="high" bgcolor="#ffffff" width="300" height="75" name="20050.swf" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">
                      </object>
                  </div>
                  <div class="col-xs-8 col-md-4 col-sm-5">
                      <a href="http://tili.kg/thanks" class="pull-left"><img height="60" src="/banners/soroskg.png"></a>
                      Сайт создан при содействии  Информационной программы Фонда «Сорос-Кыргызстан».Мнения, выраженные на сайте, не обязательно отражают точку зрения Фонда «Сорос-Кыргызстан».
                  </div>
                   <div class="netkg col-xs-4 col-md-2 col-sm-4">
                           <!-- WWW.NET.KG , code for http://tili.kg -->
                           <script language="javascript" type="text/javascript">
                            java="1.0";
                            java1=""+"refer="+escape(document.referrer)+"&amp;page="+escape(window.location.href);
                            document.cookie="astratop=1; path=/";
                            java1+="&amp;c="+(document.cookie?"yes":"now");
                           </script>
                           <script language="javascript1.1" type="text/javascript">
                            java="1.1";
                            java1+="&amp;java="+(navigator.javaEnabled()?"yes":"now");
                           </script>
                           <script language="javascript1.2" type="text/javascript">
                            java="1.2";
                            java1+="&amp;razresh="+screen.width+'x'+screen.height+"&amp;cvet="+
                            (((navigator.appName.substring(0,3)=="Mic"))?
                            screen.colorDepth:screen.pixelDepth);
                           </script>
                           <script language="javascript1.3" type="text/javascript">java="1.3"</script>
                           <script language="javascript" type="text/javascript">
                            java1+="&amp;jscript="+java+"&amp;rand="+Math.random();
                            document.write("<a href='http://www.net.kg/stat.php?id=1670&amp;fromsite=1670' target='_blank'>"+
                            "<img src='http://www.net.kg/img.php?id=1670&amp;"+java1+
                            "' border='0' alt='WWW.NET.KG' width='88' height='31' /></a>");
                           </script>
                           <noscript>
                            <a href='http://www.net.kg/stat.php?id=1670&amp;fromsite=1670' target='_blank'><img
                             src="http://www.net.kg/img.php?id=1670" border='0' alt='WWW.NET.KG' width='88'
                             height='31' /></a>
                           </noscript>
                           <!-- /WWW.NET.KG -->

                       </div>

    </div>
</div>

<?php wp_footer();?>

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter13790767 = new Ya.Metrika({id:13790767, enableAll: true, trackHash:true, webvisor:true});
        } catch(e) {}
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/13790767" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

<!--[if lte IE 6]>
<script type="text/javascript" src="http://support.ktnet.kg/js/ie6ketsin.js"></script>
<![endif]-->
<script type="text/javascript">
    var reformalOptions = {
        project_id: 66713,
        project_host: "tili.reformal.ru",
        tab_orientation: "right",
        tab_indent: "50%",
        tab_bg_color: "#72cc7d",
        tab_border_color: "#FFFFFF",
        tab_image_url: "http://tab.reformal.ru/T9GC0LfRi9Cy0Ysg0Lgg0L%252FRgNC10LTQu9C%252B0LbQtdC90LjRjw==/FFFFFF/88128dfd6ca0743b5ccc2f8afed9f3b1/right/0/tab.png",
        tab_border_width: 2
    };

    (function() {
        var script = document.createElement('script');
        script.type = 'text/javascript'; script.async = true;
        script.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'media.reformal.ru/widgets/v3/reformal.js';
        document.getElementsByTagName('head')[0].appendChild(script);
    })();
</script><noscript><a href="http://reformal.ru"><img src="http://media.reformal.ru/reformal.png" /></a><a href="http://tili.reformal.ru">Oтзывы и предложения для Tili.kg - изучение кыргызского языка онлайн</a></noscript>

</body>
</html>
