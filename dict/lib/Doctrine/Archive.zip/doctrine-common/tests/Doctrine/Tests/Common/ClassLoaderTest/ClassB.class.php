<?php

class ClassLoaderTest_ClassB
{
    
}