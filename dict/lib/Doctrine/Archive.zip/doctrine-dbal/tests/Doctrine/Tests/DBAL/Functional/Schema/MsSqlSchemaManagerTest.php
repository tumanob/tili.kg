<?php

namespace Doctrine\Tests\DBAL\Functional\Schema;

use Doctrine\DBAL\Schema;

require_once __DIR__ . '/../../../TestInit.php';
 
class MsSqlSchemaManagerTest extends SchemaManagerFunctionalTestCase
{
    
}